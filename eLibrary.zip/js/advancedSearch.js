
///////////////////////////////////////////////////////////////Advanced Search for a Book///////////////////////////

document.getElementById("searchBook").addEventListener("click", searchBook)

async function searchBook() {
    try {
        let bookTitle = document.getElementById("bookTitleA").value;
        let bookTitleLowerCase = bookTitle.toLowerCase();

        let bookISBN = parseInt(document.getElementById("bookISBN").value);

        let count = 0;

        if (bookTitle == "" || bookISBN == "") {
            document.getElementById("Asearch").innerHTML = `Enter values to both book title and ISBN`;
        } else {
            let response = await fetch('https://elibraryrestapi.herokuapp.com/elibrary/api/book/list',
                {
                    method: "GET",
                    headers: { 'content-type': 'application/json' }
                })

            let responseData = await response.json();
            for (let i = 0; i < responseData.length; i++) {
                if (responseData[i].title.toLowerCase() == bookTitleLowerCase && responseData[i].isbn == bookISBN) {
                    count++;
                }
            }

            if (count == 0) {
                document.getElementById("Asearch").innerHTML = `A book with title: ${bookTitle} and ISBN: ${bookISBN} is not available`;

            } else {
                document.getElementById("Asearch").innerHTML = `The book with title: ${bookTitle} and ISBN: ${bookISBN} is available`;

            }
        }
    }
    catch (err) {
        console.log(err)
    }
}



document.getElementById("resetSearch").addEventListener("click", function () {
    document.getElementById("bookTitle").value = ""

})


