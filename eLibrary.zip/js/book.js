


///////////////////////////////////////////////////////////////Displaying books///////////////////////////


async function getBooks() {

    let response = await fetch('https://elibraryrestapi.herokuapp.com/elibrary/api/book/list',
        {
            method: "GET",
            headers: { 'content-type': 'application/json' }
        })

    let responseData = await response.json();
    const table = document.getElementById("tableData");

    let tableContent = `
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">isbn</th>
                        <th scope="col">title</th>
                        <th scope="col">overduepay</th>
                        <th scope="col">publisher</th>
                        <th scope="col">Date published</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>



                    </tr>
                </thead>
                <tbody>`;
    let count = 0;
    responseData.forEach(element => {
        ++count;
        tableContent += `
                    <tr class="table-active">
                        <th scope="row">${count}</th>
                        <td>${element.isbn}</td>
                        <td>${element.title}</td>
                        <td>${element.overdueFee}</td>
                        <td>${element.publisher}</td>
                        <td>${element.datePublished}</td>
                        <td><a href="editBook.html?bookId=${element.bookId}">Edit</a></td>
                        <td><a data-toggle="modal" data-bookid="${element.bookId}" data-bookisbn="${element.isbn}"
                        data-booktitle="${element.title}" href="#confirmDeleteBookModal">Delete</a></td>

                    </tr> 
                    `;
    });

    table.innerHTML = tableContent;


}


getBooks();



/////////////////////////////////////////////////////////////Deleting a book//////////////////////
$(document).ready(function () {
    $("#confirmDeleteBookModal").on("show.bs.modal", deletingBook)

    function deletingBook(event) {

        const deletLink = $(event.relatedTarget);
        const bookId = deletLink.data("bookid")
        const bookISBN = deletLink.data("bookisbn")
        const bookTitle = deletLink.data("booktitle")

        document.getElementById("deleteModalBookISBN").innerHTML = "ISBN: " + bookISBN;
        document.getElementById("deleteModalBookTitle").innerHTML = "Book Title: " + bookTitle;


        $("#deleteModalBtnYes").on("click", function () {
            fetch(`https://elibraryrestapi.herokuapp.com/elibrary/api/book/delete/${bookId}`,
                {
                    method: "delete",
                    headers: { 'Content-type': 'application/json' },

                }).then(function () {
                    alert(`Successfully deleted book title: ${bookTitle} and book number: ${bookISBN}`);
                    $("#confirmDeleteBookModal").modal('hide')
                })
        })
    }
})

