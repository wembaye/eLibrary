

const params = new URLSearchParams(window.location.search);
const bookId = params.get("bookId");
console.log(bookId);

getBook()
async function getBook() {

    let response = await fetch(`https://elibraryrestapi.herokuapp.com/elibrary/api/book/delete/${bookId}`,
        {
            method: "DELETE",
            headers: { 'Content-type': 'application/json' },

        })
    
}



