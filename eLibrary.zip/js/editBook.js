

const params = new URLSearchParams(window.location.search);
const bookId = params.get("bookId");
console.log(bookId);

getBook()
async function getBook() {

    let response = await fetch(`https://elibraryrestapi.herokuapp.com/elibrary/api/book/get/${bookId}`,
        {
            method: "GET",
            headers: { 'Content-type': 'application/json' },

        })
    let responseData = await response.json();
    document.getElementById("inputId").value = responseData.bookId;
    document.getElementById("input1").value = responseData.title;
    document.getElementById("input2").value = responseData.isbn;
    document.getElementById("input3").value = responseData.overdueFee;
    document.getElementById("input4").value = responseData.publisher;
    document.getElementById("input5").value = responseData.datePublished;

}



let addBook = document.getElementById("book1");
addBook.addEventListener("click", postBook)


async  function postBook() {

    let bookId = parseInt(document.getElementById("inputId").value);
    let bookTitle = document.getElementById("input1").value;
    let isBn = document.getElementById("input2").value;
    let overDue = parseFloat(document.getElementById("input3").value);
    let publish = document.getElementById("input4").value;
    let publishDate = (document.getElementById("input5").value);

    let myBook = {
        bookId: `${bookId}`, isbn: `${isBn}`, title: `${bookTitle}`, overdueFee: `${overDue}`,
        publisher: `${publish}`, datePublished: `${publishDate}`,
    }
    console.log(myBook);

   let response= await fetch(`https://elibraryrestapi.herokuapp.com/elibrary/api/book/update/${bookId}`,
        {
            method: "put",
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(myBook)

        });

        const updatedBook = await response.json();
        console.log(myBook);
        document.getElementById("inputId").value = ""
        document.getElementById("input1").value = ""
        document.getElementById("input2").value = ""
        document.getElementById("input3").value = ""
        document.getElementById("input4").value = ""
        document.getElementById("input5").value = ""
}


