
let addBook = document.getElementById("book1");
addBook.addEventListener("click", postBook)


function postBook() {

    let bookTitle = document.getElementById("input1").value;
    let isBn = parseInt(document.getElementById("input2").value);
    let overDue = parseFloat(document.getElementById("input3").value);
    let publish = document.getElementById("input4").value;
    let publishDate = (document.getElementById("input5").value);

    let myBook = {
        isbn: `${isBn}`, title: `${bookTitle}`, overdueFee: `${overDue}`,
        publisher: `${publish}`, datePublished: `${publishDate}`,
    }
    console.log(myBook)

    fetch('https://elibraryrestapi.herokuapp.com/elibrary/api/book/add',
        {
            method: "POST",
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(myBook)

        })
}

document.getElementById("book2").addEventListener("click",function(){
document.getElementById("input1").value=""
document.getElementById("input2").value=""
document.getElementById("input3").value=""
document.getElementById("input4").value=""
document.getElementById("input5").value=""

})



