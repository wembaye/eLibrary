
///////////////////////////////////////////////////////////////Quick Search for a Book///////////////////////////

document.getElementById("searchBook").addEventListener("click", searchBook)

async function searchBook() {
    let bookTitle = document.getElementById("bookTitle").value;

    if (bookTitle == "") {
        document.getElementById("tableData").innerHTML = `Enter a book title`

    } else {
        let response = await fetch('https://elibraryrestapi.herokuapp.com/elibrary/api/book/list',
            {
                method: "GET",
                headers: { 'content-type': 'application/json' }
            })

        let responseData = await response.json();

        let filteredData = responseData.filter(book => book.title.toLowerCase().includes(bookTitle.toLowerCase()))
        if (filteredData.length == 0) {
            document.getElementById("tableData").innerHTML = `There are no books available with book title: ${bookTitle} `
        } else {
            let table = document.getElementById("tableData");

            let tableContent = `
            <h1 style="color:black; font-size:20px"> A book with the given title is available. Find the lists on the table below </h1>
            <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">isbn</th>
                            <th scope="col">title</th>
                            <th scope="col">overduepay</th>
                            <th scope="col">publisher</th>
                            <th scope="col">Date published</th>    
    
                        </tr>
                    </thead>
                    <tbody>`;
            let count = 0;
            filteredData.forEach(element => {
                ++count;
                tableContent += `
                        <tr class="table-active">
                            <th scope="row">${count}</th>
                            <td>${element.isbn}</td>
                            <td>${element.title}</td>
                            <td>${element.overdueFee}</td>
                            <td>${element.publisher}</td>
                            <td>${element.datePublished}</td>
                           
                        </tr> 
                        `;
            });

            table.innerHTML = tableContent;

        }

        
    }

}



document.getElementById("resetSearch").addEventListener("click", function () {
    document.getElementById("bookTitle").value = ""

})


